//
//  FarmLog+CoreDataProperties.swift
//  farmlog
//
//  Created by Allnet Systems on 4/30/25.
//
//

import Foundation
import CoreData


extension FarmLog {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<FarmLog> {
        return NSFetchRequest<FarmLog>(entityName: "FarmLog")
    }

    @NSManaged public var activity: String?
    @NSManaged public var crop: String?
    @NSManaged public var date: Date?
    @NSManaged public var id: UUID?
    @NSManaged public var notes: String?

}

extension FarmLog : Identifiable {

}
