import CoreData
import SwiftUI

class CoreDataManager {
    static let shared = CoreDataManager()

    let persistentContainer: NSPersistentContainer

    private init() {
        persistentContainer = NSPersistentContainer(name: "FarmLogApp")
        persistentContainer.loadPersistentStores { _, error in
            if let error = error {
                fatalError("Error loading Core Data: \(error)")
            }
        }
    }

    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }

    func saveContext() {
        do {
            try context.save()
        } catch {
            print("Error saving Core Data: \(error)")
        }
    }

    // Save user credentials (email and password) to Core Data
    func saveUser(email: String, password: String) -> Bool {
        let context = self.context
        let newUser = User(context: context)

        newUser.email = email
        newUser.password = password

        do {
            try context.save()
            return true
        } catch {
            print("Failed to save user: \(error)")
            return false
        }
    }

    func validateUser(email: String, password: String) -> Bool {
        let context = self.context
        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "email == %@", email)

        do {
            let users = try context.fetch(fetchRequest)
            if let user = users.first, user.password == password {
                return true
            }
        } catch {
            print("Failed to fetch users: \(error)")
        }
        return false
    }
}
