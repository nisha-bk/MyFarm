import SwiftUI

struct SignupView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var isSignedUp = false

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.blue, Color.green]),
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                VStack {
                    Spacer()

                    VStack(spacing: 16) {
                        Image(systemName: "leaf.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80, height: 80)
                            .foregroundColor(.white)
                            .shadow(radius: 8)

                        Text("FarmLog")
                            .font(.largeTitle.bold())
                            .foregroundColor(.white)
                    }
                    .padding(.bottom, 20)

                    VStack(spacing: 16) {
                        CustomtextField(placeholder: "Email", text: $email, isSecure: false)
                        CustomtextField(placeholder: "Password", text: $password, isSecure: true)
                        CustomtextField(placeholder: "Confirm Password", text: $confirmPassword, isSecure: true)

                        Button(action: signUp) {
                            Text("Sign Up")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(
                                    LinearGradient(colors: [Color.green, Color.blue],
                                                   startPoint: .leading,
                                                   endPoint: .trailing)
                                )
                                .cornerRadius(12)
                                .shadow(color: .black.opacity(0.2), radius: 5, x: 0, y: 4)
                        }

                        NavigationLink("Already have an account? Log In", destination: LoginView())
                            .font(.footnote)
                            .foregroundColor(.white.opacity(0.85))
                            .underline()
                    }
                    .padding(24)
                    .background(.ultraThinMaterial)
                    .cornerRadius(20)
                    .shadow(radius: 10)
                    .padding(.horizontal, 30)

                    Spacer()
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text(isSignedUp ? "Sign Up Successful" : "Error"),
                    message: Text(alertMessage),
                    dismissButton: .default(Text("OK")) {
                        if isSignedUp {
                            isSignedUp = true
                        }
                    }
                )
            }
            .fullScreenCover(isPresented: $isSignedUp) {
                LoginView()
            }
        }
    }

    func signUp() {
        if email.isEmpty || password.isEmpty || confirmPassword.isEmpty {
            alertMessage = "All fields are required."
        } else if !isValidEmail(email) {
            alertMessage = "Please enter a valid email address."
        } else if !isValidPassword(password) {
            alertMessage = "Password must include uppercase, lowercase, number, and be at least 6 characters."
        } else if password != confirmPassword {
            alertMessage = "Passwords do not match."
        } else {
            let success = CoreDataManager.shared.saveUser(email: email, password: password)
            if success {
                alertMessage = "Sign up successful!"
                isSignedUp = true
            } else {
                alertMessage = "Sign up failed. Try again."
            }
        }
        showAlert = true
    }

    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        return NSPredicate(format: "SELF MATCHES %@", emailRegEx).evaluate(with: email)
    }

    func isValidPassword(_ password: String) -> Bool {
        let passwordRegEx = "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).{6,}$"
        return NSPredicate(format: "SELF MATCHES %@", passwordRegEx).evaluate(with: password)
    }
}


struct CustomtextField: View {
    var placeholder: String
    @Binding var text: String
    var isSecure: Bool

    var body: some View {
        Group {
            if isSecure {
                SecureField(placeholder, text: $text)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 10).strokeBorder(Color.white, lineWidth: 2).background(RoundedRectangle(cornerRadius: 10).fill(Color.white.opacity(0.2))))
                    .foregroundColor(.white)
            } else {
                TextField(placeholder, text: $text)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 10).strokeBorder(Color.white, lineWidth: 2).background(RoundedRectangle(cornerRadius: 10).fill(Color.white.opacity(0.2))))
                    .foregroundColor(.white)
            }
        }
        .padding(.horizontal, 15)
        .frame(maxWidth: .infinity)
    }
}
