//
//  farmlogApp.swift
//  farmlog
//
//  Created 

import SwiftUI

@main
struct FarmLogApp: App {
    let persistenceController = CoreDataManager.shared
    @AppStorage("isLoggedIn") var isLoggedIn: Bool = false

        var body: some Scene {
            WindowGroup {
                SplashView()
                    .environment(\.managedObjectContext, persistenceController.context)
            }
        }
}
