import SwiftUI

struct SettingsView: View {
    @AppStorage("isDarkMode") private var isDarkMode: Bool = false  // Store dark mode setting
    @AppStorage("notificationsEnabled") private var notificationsEnabled: Bool = true
    @AppStorage("selectedLanguage") private var selectedLanguage: String = "English" // Store language setting
    @State private var showProfile: Bool = false
    @State private var isLocationEnabled: Bool = true
    
    // Mock user data for the profile
    @State private var userProfile = UserProfile(name: "John Doe", email: "johndoe@example.com", profilePicture: "person.circle.fill")
    
    // Localized strings based on the language selected
//    private var headingText: String {
//        switch selectedLanguage {
//        case "Spanish": return "⚙️ Ajustes"
//        case "French": return "⚙️ Paramètres"
//        case "German": return "⚙️ Einstellungen"
//        default: return "⚙️ Settings"
//        }
//    }
    
    private var displayText: String {
        switch selectedLanguage {
        case "Spanish": return "Personaliza tu experiencia FarmLog."
        case "French": return "Personnalisez votre expérience FarmLog."
        case "German": return "Passen Sie Ihre FarmLog-Erfahrung an."
        default: return "Customize your FarmLog experience."
        }
    }
    
    private var darkModeText: String {
        switch selectedLanguage {
        case "Spanish": return "Activar Modo Oscuro"
        case "French": return "Activer le Mode Sombre"
        case "German": return "Dunkelmodus aktivieren"
        default: return "Enable Dark Mode"
        }
    }
    
    private var notificationText: String {
        switch selectedLanguage {
        case "Spanish": return "Activar Notificaciones"
        case "French": return "Activer les Notifications"
        case "German": return "Benachrichtigungen aktivieren"
        default: return "Enable Notifications"
        }
    }
    
    private var languageText: String {
        switch selectedLanguage {
        case "Spanish": return "Configuración de Idioma"
        case "French": return "Paramètres de Langue"
        case "German": return "Spracheinstellungen"
        default: return "Language Settings"
        }
    }
    
    private var locationText: String {
        switch selectedLanguage {
        case "Spanish": return "Habilitar Acceso a Ubicación"
        case "French": return "Activer l'accès à la localisation"
        case "German": return "Standortzugriff aktivieren"
        default: return "Enable Location Access"
        }
    }
    
    private var profileText: String {
        switch selectedLanguage {
        case "Spanish": return "Ver Perfil"
        case "French": return "Voir le Profil"
        case "German": return "Profil anzeigen"
        default: return "View Profile"
        }
    }
    
    private var resetSettingsText: String {
        switch selectedLanguage {
        case "Spanish": return "Restablecer a Predeterminado"
        case "French": return "Réinitialiser par Défaut"
        case "German": return "Auf Standard zurücksetzen"
        default: return "Reset to Default"
        }
    }

    var body: some View {
        NavigationView {
            ZStack {
                // Background gradient
                LinearGradient(gradient: Gradient(colors: [Color("PrimaryColor"), Color("SecondaryColor")]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .edgesIgnoringSafeArea(.all)
                
                VStack {
                    // Header Section
                    VStack(alignment: .center, spacing: 10) {
//                        Text(headingText)
//                            .font(.largeTitle)
//                            .fontWeight(.bold)
//                            .foregroundColor(.white)
//                            .frame(maxWidth: .infinity, alignment: .center)
                        
                        Text(displayText)
                            .foregroundColor(.gray)
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .padding(.top)
                    .padding(.horizontal)
                    
                    // Settings Options List
                    Form {
                        // Dark Mode Toggle Section
                        Section(header: Text("Display Settings")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(LinearGradient(gradient: Gradient(colors: [Color("PrimaryColor"), Color("SecondaryColor")]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .cornerRadius(10)) {
                            Toggle(darkModeText, isOn: $isDarkMode)
                                .padding()
                                .toggleStyle(SwitchToggleStyle(tint: Color("PrimaryColor")))
                                .onChange(of: isDarkMode) { _ in
                                    let generator = UIImpactFeedbackGenerator(style: .medium)
                                    generator.impactOccurred()
                                }
                        }
                        
                        // Notification Toggle Section
                        Section(header: Text("Notifications")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(LinearGradient(gradient: Gradient(colors: [Color("PrimaryColor"), Color("SecondaryColor")]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .cornerRadius(10)) {
                            Toggle(notificationText, isOn: $notificationsEnabled)
                                .padding()
                                .toggleStyle(SwitchToggleStyle(tint: Color("PrimaryColor")))
                                .onChange(of: notificationsEnabled) { _ in
                                    let generator = UIImpactFeedbackGenerator(style: .medium)
                                    generator.impactOccurred()
                                }
                        }
                        
                        // Language Settings Section
                        Section(header: Text(languageText)
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(LinearGradient(gradient: Gradient(colors: [Color("PrimaryColor"), Color("SecondaryColor")]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .cornerRadius(10)) {
                            Picker("Preferred Language", selection: $selectedLanguage) {
                                Text("English").tag("English")
                                Text("Spanish").tag("Spanish")
                                Text("French").tag("French")
                                Text("German").tag("German")
                            }
                            .pickerStyle(MenuPickerStyle())
                        }
                        
                        // Location Services Section
                        Section(header: Text("Privacy Settings")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(LinearGradient(gradient: Gradient(colors: [Color("PrimaryColor"), Color("SecondaryColor")]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .cornerRadius(10)) {
                            Toggle(locationText, isOn: $isLocationEnabled)
                                .padding()
                                .toggleStyle(SwitchToggleStyle(tint: Color("PrimaryColor")))
                        }
                        
                        // Profile Section - Navigate to Profile View
                        Section(header: Text("User Profile")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(LinearGradient(gradient: Gradient(colors: [Color("PrimaryColor"), Color("SecondaryColor")]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .cornerRadius(10)) {
                            NavigationLink(destination: ProfileView(userProfile: $userProfile)) {
                                HStack {
                                    Image(systemName: "person.circle.fill")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 40, height: 40)
                                        .padding()
                                    Text(profileText)
                                        .font(.headline)
                                        .foregroundColor(.white)
                                    Spacer()
                                    Image(systemName: "chevron.right.circle.fill")
                                        .foregroundColor(.white)
                                }
                            }
                        }
                        
                        // App Info Section
                        Section(header: Text("App Info")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(LinearGradient(gradient: Gradient(colors: [Color("PrimaryColor"), Color("SecondaryColor")]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .cornerRadius(10)) {
                            VStack(alignment: .leading, spacing: 5) {
                                Text("Version 1.0.0")
                                    .font(.subheadline)
                                    .foregroundColor(.white)
                                
                                Text("© 2025 FarmLog. All rights reserved.")
                                    .font(.subheadline)
                                    .italic()
                                    .foregroundColor(.gray)
                            }
                            .padding(.vertical)
                        }
                        
                        // Reset Settings Section
                        Section(header: Text("Reset Settings")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(LinearGradient(gradient: Gradient(colors: [Color("PrimaryColor"), Color("SecondaryColor")]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .cornerRadius(10)) {
                            Button(action: resetSettings) {
                                HStack {
                                    Text(resetSettingsText)
                                        .foregroundColor(.red)
                                    Spacer()
                                    Image(systemName: "arrow.uturn.backward.circle.fill")
                                        .foregroundColor(.red)
                                }
                            }
                        }
                    }
                    .scrollContentBackground(.hidden)
                    .background(Color("BackgroundColor"))
                    .cornerRadius(15)
                    .shadow(radius: 10)
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
        }
        .preferredColorScheme(isDarkMode ? .dark : .light)  // Apply dark or light mode
    }
    
    // Reset all settings to default
    private func resetSettings() {
        isDarkMode = false
        notificationsEnabled = true
        selectedLanguage = "English"
        isLocationEnabled = true
    }
}

struct ProfileView: View {
    @Binding var userProfile: UserProfile
    
    var body: some View {
        VStack {
            Text("User Profile")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
            
            // Profile Picture
            Image(systemName: userProfile.profilePicture)
                .resizable()
                .scaledToFit()
                .frame(width: 150, height: 150)
                .padding()
            
            // Editable Profile Information
            VStack(alignment: .leading, spacing: 15) {
                Text("Name:")
                    .font(.headline)
                TextField("Enter your name", text: $userProfile.name)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Text("Email:")
                    .font(.headline)
                TextField("Enter your email", text: $userProfile.email)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
            }
            .padding(.horizontal)
            
            Spacer()
            
            Button(action: saveProfile) {
                Text("Save Changes")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(LinearGradient(gradient: Gradient(colors: [Color("PrimaryColor"), Color("SecondaryColor")]), startPoint: .topLeading, endPoint: .bottomTrailing))
                    .cornerRadius(10)
                    .shadow(radius: 5)
            }
            .padding()
        }
        .padding()
    }
    
    private func saveProfile() {
        // Here you would typically save changes to a database or persistent storage.
        // For this example, we just print the updated profile.
        print("Profile saved: \(userProfile.name), \(userProfile.email)")
    }
}

// Mock User Profile Model
struct UserProfile {
    var name: String
    var email: String
    var profilePicture: String // Using an SF Symbol for the profile picture
}
