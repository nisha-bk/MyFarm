import SwiftUI

struct FarmEquipmentView: View {
    @State private var equipmentList: [String] = []
    @State private var newEquipment: String = ""
    @State private var showingAddEquipmentAlert = false
    @State private var searchQuery: String = ""

    var filteredEquipment: [String] {
        if searchQuery.isEmpty {
            return equipmentList
        } else {
            return equipmentList.filter { $0.localizedCaseInsensitiveContains(searchQuery) }
        }
    }

    var body: some View {
        VStack {
            Text("🚜 Farm Equipment")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()

            // Search Bar
            TextField("Search Equipment", text: $searchQuery)
                .padding()
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)

            // Equipment List
            List {
                ForEach(filteredEquipment, id: \.self) { equipment in
                    Text(equipment)
                }
                .onDelete(perform: deleteEquipment)
            }
            .padding()

            // Add New Equipment Section
            VStack {
                TextField("Enter Equipment (e.g., Tractor)", text: $newEquipment)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                Button(action: addEquipment) {
                    Text("Add Equipment")
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding(.top)
                .disabled(newEquipment.isEmpty) // Disable button if text field is empty
            }
            .padding()
        }
        .navigationTitle("Farm Equipment")
        .onAppear(perform: loadEquipment) // Load equipment list when the view appears
        .alert(isPresented: $showingAddEquipmentAlert) {
            Alert(title: Text("New Equipment Added"),
                  message: Text("You have successfully added the equipment."),
                  dismissButton: .default(Text("OK")))
        }
    }

    // Add Equipment function
    private func addEquipment() {
        if !newEquipment.isEmpty {
            equipmentList.append(newEquipment)
            newEquipment = "" // Clear the text field after adding
            showingAddEquipmentAlert = true
            saveEquipment() // Save updated equipment list
        }
    }

    // Delete Equipment function
    private func deleteEquipment(at offsets: IndexSet) {
        equipmentList.remove(atOffsets: offsets)
        saveEquipment() // Save updated equipment list after deletion
    }

    // Save Equipment list to UserDefaults
    private func saveEquipment() {
        let defaults = UserDefaults.standard
        defaults.set(equipmentList, forKey: "equipmentList")
    }

    // Load Equipment list from UserDefaults
    private func loadEquipment() {
        if let savedEquipment = UserDefaults.standard.array(forKey: "equipmentList") as? [String] {
            equipmentList = savedEquipment
        }
    }
}
