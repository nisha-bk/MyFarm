import SwiftUI

struct AddExpenseView: View {
    @Environment(\.managedObjectContext) private var viewContext

    @State private var title = ""
    @State private var amount = ""
    @State private var category = ""
    @State private var date = Date()

    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [
                colorScheme == .dark ? Color.orange.opacity(0.3) : Color.orange.opacity(0.2),
                colorScheme == .dark ? Color.pink.opacity(0.3) : Color.pink.opacity(0.2)
            ]), startPoint: .topLeading, endPoint: .bottomTrailing)
            .edgesIgnoringSafeArea(.all)

            VStack {
                Form {
                    Section(header: Text("💰 Expense Details").foregroundColor(.orange)) {
                        CustomTextField(placeholder: "Expense Title", text: $title)
                        CustomTextField(placeholder: "Amount", text: $amount)
                            .keyboardType(.decimalPad)
                        CustomTextField(placeholder: "Category", text: $category)
                        DatePicker("Date", selection: $date, displayedComponents: .date)
                            .accentColor(.orange)
                    }
                }
                .scrollContentBackground(.hidden)
                .background(Color.clear)

                Button(action: saveExpense) {
                    Text("✅ Save Expense")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(LinearGradient(gradient: Gradient(colors: [
                            colorScheme == .dark ? Color.orange : Color.orange,
                            colorScheme == .dark ? Color.pink : Color.pink
                        ]), startPoint: .leading, endPoint: .trailing))
                        .cornerRadius(12)
                        .shadow(radius: 5)
                }
                .padding()
            }
            .padding([.top, .horizontal])
        }
        .navigationTitle("Add Expense")
    }

    private func saveExpense() {
        let newExpense = Expense(context: viewContext)
        newExpense.id = UUID()
        newExpense.title = title
        newExpense.amount = Double(amount) ?? 0.0
        newExpense.category = category
        newExpense.date = date

        do {
            try viewContext.save()
            print("✅ Expense Saved!")
        } catch {
            print("❌ Error saving expense: \(error)")
        }
    }
}

struct CustomTextField: View {
    var placeholder: String
    @Binding var text: String

    var body: some View {
        TextField(placeholder, text: $text)
            .padding()
            .background(Color.white)
            .cornerRadius(8)
            .shadow(radius: 2)
            .textFieldStyle(RoundedBorderTextFieldStyle())
    }
}
