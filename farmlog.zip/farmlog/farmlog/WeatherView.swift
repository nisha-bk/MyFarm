import SwiftUI

struct WeatherView: View {
    @State private var weatherData: WeatherData?
    @State private var cityName: String = "London"
    @State private var isLoading = true
    @State private var errorMessage: String?
    @State private var searchQuery: String = ""

    var body: some View {
        VStack {
            // Title and City Search
            Text("🌦 Weather Radar")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()

            // City Search TextField
            HStack {
                TextField("Enter City", text: $searchQuery)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .autocapitalization(.none)
                
                Button(action: {
                    cityName = searchQuery
                    fetchWeatherData(for: cityName)
                }) {
                    Text("Search")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(8)
                }
            }
            .padding(.horizontal)

            // Loading, Error, or Weather Data View
            if isLoading {
                ProgressView("Loading...")
                    .progressViewStyle(CircularProgressViewStyle())
                    .padding()
            } else if let weather = weatherData {
                Text("Today: \(weather.currentWeather) \(weather.currentTemperature)°C")
                    .font(.title)
                    .padding()

                // Forecast
                VStack(alignment: .leading, spacing: 10) {
                    Text("Next 3 Days:")
                        .font(.headline)
                        .padding(.top)

                    ForEach(weather.forecast, id: \.day) { forecast in
                        Text("\(forecast.day): \(forecast.weather)")
                            .font(.body)
                            .foregroundColor(.gray)
                    }
                }
                .padding()
            } else {
                Text("Error: \(errorMessage ?? "Unknown error")")
                    .foregroundColor(.red)
                    .padding()
                
                Button("Retry") {
                    fetchWeatherData(for: cityName)
                }
                .padding()
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(8)
            }
        }
        .onAppear {
            fetchWeatherData(for: cityName)
        }
        .background(LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.3), Color.purple.opacity(0.3)]), startPoint: .topLeading, endPoint: .bottomTrailing))
        .edgesIgnoringSafeArea(.all)
//        .navigationTitle("Weather Radar")
    }

    func fetchWeatherData(for city: String) {
        let apiKey = "YOUR_API_KEY"
        let urlString = "https://api.openweathermap.org/data/2.5/forecast?q=\(city)&cnt=4&appid=\(apiKey)&units=metric"
        guard let url = URL(string: urlString) else {
            self.errorMessage = "Invalid URL"
            self.isLoading = false
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
                return
            }

            guard let data = data else {
                DispatchQueue.main.async {
                    self.errorMessage = "No data received"
                    self.isLoading = false
                }
                return
            }

            do {
                let decodedData = try JSONDecoder().decode(WeatherResponse.self, from: data)
                DispatchQueue.main.async {
                    self.weatherData = WeatherData(
                        currentWeather: decodedData.list[0].weather[0].main,
                        currentTemperature: decodedData.list[0].main.temp,
                        forecast: decodedData.list[1...3].map {
                            Forecast(day: formatDate(from: $0.dt_txt), weather: $0.weather[0].main)
                        }
                    )
                    self.isLoading = false
                }
            } catch {
                DispatchQueue.main.async {
                    self.errorMessage = "Failed to decode weather data"
                    self.isLoading = false
                }
            }
        }
        .resume()
    }

    private func formatDate(from rawDate: String) -> String {
        // Extracting the day of the week (e.g., "Monday")
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        if let date = dateFormatter.date(from: rawDate) {
            dateFormatter.dateFormat = "EEEE" // Full weekday name
            return dateFormatter.string(from: date)
        }
        return rawDate // Fallback to raw date string
    }
}

// MARK: - Weather Model

struct WeatherData {
    let currentWeather: String
    let currentTemperature: Double
    let forecast: [Forecast]
}

struct Forecast {
    let day: String
    let weather: String
}

struct WeatherResponse: Decodable {
    let list: [WeatherListItem]
}

struct WeatherListItem: Decodable {
    let dt_txt: String
    let weather: [WeatherDescription]
    let main: WeatherMain
}

struct WeatherDescription: Decodable {
    let main: String
}

struct WeatherMain: Decodable {
    let temp: Double
}
