import SwiftUI

struct DashboardView: View {
    var body: some View {
        NavigationView {
            ZStack {
                
                LinearGradient(gradient: Gradient(colors: [Color.green.opacity(0.2), Color.blue.opacity(0.2)]),
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                    .edgesIgnoringSafeArea(.all)

                ScrollView {
                    VStack(spacing: 20) {
                        Text("FarmLog Dashboard")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundStyle(
                                    LinearGradient(gradient: Gradient(colors: [Color.blue, Color.green]), startPoint: .leading, endPoint: .trailing)
                                )       

                            DashboardButton(icon: "plus.circle.fill", label: "Add Farm Log", color: .blue, destination: AddFarmLogView())
                            DashboardButton(icon: "dollarsign.circle.fill", label: "Add Expense", color: .orange, destination: AddExpenseView())
                    
                            DashboardButton(icon: "list.bullet", label: "Farm Logs", color: .green, destination: FarmLogsListView())
                            DashboardButton(icon: "creditcard.fill", label: "Expenses", color: .red, destination: ExpensesListView())
                     
                            DashboardButton(icon: "leaf.fill", label: "Crop Management", color: .purple, destination: CropManagementView())
                            DashboardButton(icon: "shippingbox.fill", label: "Inventory", color: .brown, destination: InventoryView())
                        
                            DashboardButton(icon: "cloud.sun.fill", label: "Weather", color: .cyan, destination: WeatherView())
                            DashboardButton(icon: "chart.bar.fill", label: "Reports", color: .yellow, destination: ReportsView())
                     
                            DashboardButton(icon: "calendar.circle.fill", label: "Calendar", color: .pink, destination: FarmersCalendarView())
                            DashboardButton(icon: "checkmark.circle.fill", label: "Task Tracker", color: .green, destination: TaskTrackerView())
                        
                            DashboardButton(icon: "archivebox.fill", label: "Harvest Log", color: .blue, destination: HarvestLogView())
                            DashboardButton(icon: "gearshape.fill", label: "Settings", color: .gray, destination: SettingsView())
                             
                            DashboardButton(icon: "arrow.backward.circle.fill", label: "Logout", color: .teal, destination: LoginView())
                        Spacer()
                    }
                    .padding()
                }
            }
        }
    }
}


struct DashboardButton<Destination: View>: View {
    let icon: String
    let label: String
    let color: Color
    let destination: Destination

    var body: some View {
        NavigationLink(destination: destination) {
            HStack(spacing: 10) {
                Image(systemName: icon)
                    .foregroundColor(.white)
                    .font(.title)
                Text(label)
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(color)
            .cornerRadius(15)
            .shadow(color: color.opacity(0.5), radius: 8, x: 0, y: 5)
            .scaleEffect(0.98)
            .animation(.easeInOut(duration: 0.2), value: 1.0)
        }
        .buttonStyle(PlainButtonStyle())
    }
}
