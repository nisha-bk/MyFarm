import SwiftUI

struct ExpensesListView: View {
    @FetchRequest(entity: Expense.entity(), sortDescriptors: [NSSortDescriptor(keyPath: \Expense.date, ascending: false)])
    var expenses: FetchedResults<Expense>

    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        ZStack {
            // Dynamic background gradient for light and dark modes
            LinearGradient(gradient: Gradient(colors: [
                colorScheme == .dark ? Color.orange.opacity(0.3) : Color.orange.opacity(0.2),
                colorScheme == .dark ? Color.purple.opacity(0.3) : Color.purple.opacity(0.2)
            ]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)

            VStack {
                if expenses.isEmpty {
                    // Placeholder for no expenses
                    VStack {
                        Image(systemName: "creditcard.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .foregroundColor(colorScheme == .dark ? .orange : .orange.opacity(0.7))
                        Text("No expenses yet! Start tracking 💰")
                            .font(.headline)
                            .foregroundColor(.gray)
                            .padding()
                    }
                } else {
                    List {
                        ForEach(expenses, id: \.self) { expense in
                            HStack(spacing: 15) {
                                Image(systemName: "dollarsign.circle.fill")
                                    .foregroundColor(categoryColor(expense.category ?? "Other"))
                                    .font(.title)

                                VStack(alignment: .leading) {
                                    Text(expense.title ?? "Unknown")
                                        .font(.headline)
                                        .foregroundColor(colorScheme == .dark ? .white : .black)

                                    Text("\(String(format: "%.2f", expense.amount)) USD")
                                        .font(.subheadline)
                                        .foregroundColor(colorScheme == .dark ? .gray : .secondary)

                                    Text("📅 \(expense.date ?? Date(), formatter: dateFormatter)")
                                        .font(.caption)
                                        .foregroundColor(colorScheme == .dark ? .white : .gray)
                                }
                            }
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(colorScheme == .dark ? Color.black.opacity(0.3) : Color.white)
                                    .shadow(radius: 5)
                            )
                        }
                        .onDelete(perform: deleteExpense)
                    }
                    .scrollContentBackground(.hidden)
                    .background(Color.clear)
                }
            }
        }
        .navigationTitle("💰 Expenses")
        .toolbar {
            EditButton()
                .foregroundColor(colorScheme == .dark ? .red : .blue) // Dynamic button color
        }
    }

    private func deleteExpense(at offsets: IndexSet) {
        for index in offsets {
            viewContext.delete(expenses[index])
        }
        try? viewContext.save()
    }

    // Function to assign colors based on category
    private func categoryColor(_ category: String) -> Color {
        switch category.lowercased() {
        case "food": return .green
        case "transport": return .blue
        case "supplies": return .orange
        default: return .gray
        }
    }
}

private let dateFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .medium
    return formatter
}()
