import SwiftUI

struct TaskTrackerView: View {
    @State private var tasks: [Task] = [] {
        didSet {
            saveTasks() // Save tasks when they're updated
        }
    }
    @State private var newTask: String = ""

    struct Task: Identifiable, Codable {
        let id = UUID()
        var name: String
        var isCompleted: Bool = false
    }

    var body: some View {
        ZStack {
            // Gradient background covering the entire screen
            LinearGradient(gradient: Gradient(colors: [.blue, .green]), startPoint: .leading, endPoint: .trailing)
                .edgesIgnoringSafeArea(.all) // Ensure the gradient fills the entire screen

            VStack {
                Text("📝 Task Tracker")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()

                // Input field for new task
                TextField("Enter a new task", text: $newTask)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                // Add Task Button
                Button(action: addTask) {
                    Text("Add Task")
                        .padding()
                        .background(LinearGradient(gradient: Gradient(colors: [.blue, .green]), startPoint: .leading, endPoint: .trailing))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                        .shadow(radius: 10)
                }
                .padding()

                // Display Task List
                List {
                    ForEach(tasks) { task in
                        HStack {
                            // Toggle Task Completion
                            Button(action: {
                                toggleCompletion(for: task)
                            }) {
                                Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                                    .foregroundColor(task.isCompleted ? .green : .gray)
                            }
                            .padding(.trailing)

                            // Task name with strikethrough if completed
                            Text(task.name)
                                .strikethrough(task.isCompleted, color: .gray)
                                .foregroundColor(task.isCompleted ? .gray : .primary)
                        }
                    }
                    .onDelete(perform: deleteTask)
                }
                
                // Displaying message when there are no tasks
                if tasks.isEmpty {
                    Text("No tasks added yet.")
                        .foregroundColor(.gray)
                        .italic()
                }
            }
            .padding() // Add padding inside the content to ensure it stays within screen bounds
        }
//        .navigationTitle("Task Tracker")
        .onAppear(perform: loadTasks) // Load saved tasks when the view appears
    }

    private func addTask() {
        if !newTask.isEmpty {
            let newTaskObject = Task(name: newTask)
            tasks.append(newTaskObject)
            newTask = "" // Clear the text field after adding the task
        }
    }

    private func deleteTask(at offsets: IndexSet) {
        tasks.remove(atOffsets: offsets)
    }

    private func toggleCompletion(for task: Task) {
        if let index = tasks.firstIndex(where: { $0.id == task.id }) {
            tasks[index].isCompleted.toggle()
        }
    }

    // MARK: - Persistence Methods
    
    private func saveTasks() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(tasks) {
            UserDefaults.standard.set(encoded, forKey: "tasks")
        }
    }

    private func loadTasks() {
        if let savedTasks = UserDefaults.standard.data(forKey: "tasks") {
            let decoder = JSONDecoder()
            if let decodedTasks = try? decoder.decode([Task].self, from: savedTasks) {
                tasks = decodedTasks
            }
        }
    }
}
