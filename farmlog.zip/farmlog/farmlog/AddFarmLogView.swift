import SwiftUI

struct AddFarmLogView: View {
    @Environment(\.managedObjectContext) private var viewContext

    @State private var cropName = ""
    @State private var activityType = ""
    @State private var date = Date()
    @State private var notes = ""

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.green.opacity(0.2), Color.blue.opacity(0.2)]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)

            VStack {
                Form {
                    Section(header: Text("🌱 Crop Information").foregroundColor(.green)) {
                        TextField("Crop Name", text: $cropName)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(8)

                        TextField("Activity", text: $activityType)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(8)

                        DatePicker("Date", selection: $date, displayedComponents: .date)
                            .accentColor(.blue)
                    }
                    
                    Section(header: Text("📝 Notes").foregroundColor(.blue)) {
                        TextEditor(text: $notes)
                            .frame(height: 100)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(8)
                    }
                }
                .scrollContentBackground(.hidden)
                .background(Color.clear)

                Button(action: saveFarmLog) {
                    Text("✅ Save Log")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]), startPoint: .leading, endPoint: .trailing))
                        .cornerRadius(12)
                        .shadow(radius: 5)
                }
                .padding()
            }
        }
        .navigationTitle("Add Farm Log")
    }

    private func saveFarmLog() {
        let newLog = FarmLog(context: viewContext)
        newLog.id = UUID()
        newLog.crop = cropName
        newLog.activity = activityType
        newLog.date = date
        newLog.notes = notes

        try? viewContext.save()
    }
}
