//
//  Item+CoreDataClass.swift
//  farmlog
//
//  Created by Allnet Systems on 4/30/25.
//
//

import Foundation
import CoreData

@objc(Item)
public class Item: NSManagedObject {

}
