//
//  User+CoreDataClass.swift
//  farmlog
//
//  Created by Allnet Systems on 4/30/25.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
